﻿using System;

namespace Wyzant_Yeri
{
    public class Vartuple
    {
        private string text;
        public int number;
        public Vartuple()
        {
            text = "Yeri";
            number = 10;
            Console.WriteLine("Tuple Values: {0}, {1}", text, number);
        }
        public Vartuple(string ctext)
        {
            text = ctext;
            number = 11;
            Console.WriteLine("Tuple Values: {0}, {1}", ctext, number);
        }
        public Vartuple(string ctext, int cnumber)
        {
            text = ctext;
            number = cnumber;
            Console.WriteLine("Tuple Values: {0}, {1}", ctext, cnumber);
        }
        public (string, int) getData()
        {
            return (text, number);
        }
        ~Vartuple()
        {
            Console.WriteLine("Destructor was called");
            
        }
    }
    class Contructors
    {
        static void Main(string[] args)
        {
            useTuples();
        }
        public static void useTuples()
        {
            Vartuple instance1 = new Vartuple();
            // This works
            instance1.number = 27;
            // This doesn't
            // instance1.text = "this is private!";
            Vartuple instance2 = new Vartuple("Jim", 5);
            (string item1, int item2) = instance2.getData();
        }
    }
}
